package com.zoya.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ZoyaAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screen understanding/action engine will be added incrementally.
    }

    override fun onInterrupt() {}
}
