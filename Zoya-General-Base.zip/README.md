# Zoya — General Android Base

This is the clean base project for the Zoya assistant.

## Planned incremental modules

- Voice input/output
- Zoya wake-word engine
- Persistent memory and conversation history
- MediaProjection screen capture
- OCR + AI screen vision
- Accessibility-based user-requested actions
- Phone controls
- Calls and app actions
- Notifications
- Reminders/alarms
- Floating assistant
- Animated Zoya character
- Permission/setup flow
- Final APK build and device testing

## Build in GitHub Codespaces

Use JDK 17 and Android SDK 35.

After uploading this project:

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=$HOME/android-sdk
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH

java -version
sdkmanager --version
```

Then create the Gradle wrapper:

```bash
gradle wrapper --gradle-version 8.13
chmod +x gradlew
./gradlew :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

Important: this is intentionally a clean, buildable base. Advanced assistant features are added one-by-one and must be tested on a real Android device because several Android capabilities require user-granted system permissions and device-specific behavior.
